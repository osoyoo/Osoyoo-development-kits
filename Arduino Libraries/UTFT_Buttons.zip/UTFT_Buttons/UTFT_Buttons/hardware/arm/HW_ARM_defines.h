#define bitmapdatatype unsigned short*
