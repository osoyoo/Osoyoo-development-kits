#define SECRET_SSID ""
#define SECRET_PASS ""
#define SECRET_USER_NAME ""
#define SECRET_THING_NAME ""
#define SECRET_THING_ID ""
#define SECRET_THING_PSW ""

