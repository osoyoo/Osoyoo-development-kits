#ifndef ArduinoCloud_h
#define ArduinoCloud_h

#include <ArduinoCloudThing.h>

#endif
