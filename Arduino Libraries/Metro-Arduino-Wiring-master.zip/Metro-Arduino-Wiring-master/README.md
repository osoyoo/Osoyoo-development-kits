METRO
=====================

Metro library for Arduino or Wiring that facilitates the implementation of recurring timed events
by Thomas Ouellet Fredericks
with contributions from: Paul Bouchier and Benjamin.soelberg

Download the latest version here : https://github.com/thomasfredericks/Metro-Arduino-Wiring/archive/master.zip

Documentation can be found here : https://github.com/thomasfredericks/Metro-Arduino-Wiring/wiki

