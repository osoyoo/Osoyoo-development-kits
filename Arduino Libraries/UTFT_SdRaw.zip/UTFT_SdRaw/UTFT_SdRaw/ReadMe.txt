Updated all examples which used UTouch to now use URTouch (17th August 2016)

Three examples are now provided for drawing from Serial, ARM_ProgrammingPort, ARM_NativePort and AVR. (30th October)

Re-written the loadS function to be AVR/ARM compliant and provided an Example,
also added descriptive headers to all of the examples. (29th October 2015)

Reorganised structure and added 'library.properties' file to conform to Library Spec V1.5.X (3rd August 2015)

Added the ability to draw from Serial source.

Just a SMALL update to remove the outdated #include

Also added a statistics file showing the speed increase in the ARM 800x480 example as a result of the latest SdFat version.

Thanks for downloading my UTFT_SdRaw library, please give me some 'Karma' on the forum if you appreciate my efforts.

Graham
